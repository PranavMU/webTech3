import React, { Component } from 'react'
import { useNavigate } from "react-router-dom"
import { useState } from "react"
import axios from "axios";
import { render } from '@testing-library/react';
const Login=()=>{
    
    const [login,setlogin]=useState({})
    const navigate=useNavigate()
    const handlelogin=(e)=>{
        e.preventDefault();;
        console.log(login);
        axios.post("https://webtech3-client.herokuapp.com/user/login",login).then((res)=>{
            alert("success")
            localStorage.setItem("authorization",res.data.authToken);
            localStorage.setItem("user",res.data.user)
            navigate("/posts")   
        }).catch((res)=>{
            alert("your email/phonenumber unauthorized");
        })
    }
    return (
      <form>
        <h3>Login</h3>
        <div className="mb-3">
          <label>Username</label>
          <input
            type="text"
            className="form-control"
            placeholder="UserName" onChange={(e)=>{setlogin({...login, username: e.target.value})}}
          />
        </div>
        <div className="mb-3">
          <label>Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Password" onChange={(e)=>{setlogin({...login, password: e.target.value})}} 
          />
        </div>
        <div className="d-grid">
          <button type="submit" className="btn btn-primary" onClick={handlelogin} >
            Submit
          </button>
        </div>
        <p className="forgot-password text-right">
          New user <a href="/signup">Register?</a>
        </p>
      </form>
    )
  }

export default Login