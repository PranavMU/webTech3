
import React, { Component } from 'react'
import { useNavigate } from "react-router-dom"
import { useState } from "react"
import axios from "axios";
import { render } from '@testing-library/react';
const SignUp=()=>{
    const [register,setregister]=useState({})
    const navigate=useNavigate()    
    const handleregister=(e)=>{
        e.preventDefault();;
        console.log(register);
        axios.post("https://webtech3-client.herokuapp.com/user/signup",register).then((res)=>{
            alert(res.data)
            navigate('/login')
        }).catch((res)=>{
            alert("Enter invalid input")
        })
       
    }
    return (
      <form>
        <h3>Sign Up</h3>
        <div className="mb-3">
          <label>Username</label>
          <input
            type="text"
            className="form-control"
            placeholder="UserName" onChange={(e)=>{setregister({...register, username: e.target.value})}}
          />
        </div>
        <div className="mb-3">
          <label>phoneNumber</label>
          <input
            type="text"
            className="form-control"
            placeholder="phonenumber" onChange={(e)=>{setregister({...register, phoneNumber: e.target.value})}} 
          />
        </div>
        <div className="mb-3">
          <label>Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter password" onChange={(e)=>{setregister({...register, password: e.target.value})}} 
          />
        </div>
        <div className="d-grid">
          <button type="submit" className="btn btn-primary"  onClick={handleregister}>
            Sign Up
          </button>
        </div>
        <p className="forgot-password text-right">
          Already registered <a href="/login">login?</a>
        </p>
      </form>
    )
  }
export default SignUp