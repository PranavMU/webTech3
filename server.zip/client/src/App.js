import React from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import './App.css'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import Login from "./components/login/login";
import SignUp from "./components/signup/signup";
import Logout from "./components/logout/logout";
import Posts from "./components/posts/post";
import Protected from "./components/protected-route/protected";
function App() {
  return (
    <Router>
      <div className="App">
        <nav className="navbar navbar-expand-lg navbar-light fixed-top">
          <div className="container">
            <Link className="navbar-brand" to={'/login'}>
              10x Academy
            </Link>
            <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul className="navbar-nav ml-auto">
                <li className="nav-item">
                  <Link className="nav-link" to={'/login'}>
                    Login
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to={'/signup'}>
                    Sign up
                  </Link>
                  </li>
                  <li className="nav-item">
                  <Link className="nav-link" to={'/login'}>
                    Logout
                  </Link>
                  </li>
              </ul>
            </div>
          </div>
        </nav>
        <div className="auth-wrapper">
          <div className="auth-inner">
            <Routes>
              <Route exact path="/" element={<SignUp />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/posts" element={<Posts/>}></Route>
              <Route path="/logout" element={<Logout/>}></Route>
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  )
}
export default App