import { useState, useEffect } from "react";
import CommentForm from "./commentform";
import Comment from "./comment";
import {
  getComments as getCommentsApi,
  createComment as createCommentApi,
} from "../api";
import { Link } from "react-router-dom";



const Comments = ({currentUserId }) => {
    const authToken = localStorage.getItem("authorization");
    const [Data, setData] = useState([]);
  const [backendComments, setBackendComments] = useState([]);
  const [activeComment, setActiveComment] = useState(null);
  const rootComments = backendComments.filter(
    (backendComment) => backendComment.parentId === null
  );
  const getReplies = (commentId) =>
    backendComments
      .filter((backendComment) => backendComment.parentId === commentId)
      .sort(
        (a, b) =>
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );
  const addComment = (text, parentId) => {
    createCommentApi(text, parentId).then((comment) => {
      setBackendComments([comment, ...backendComments]);
      setActiveComment(null);
    });
  };



  useEffect(() => {
    getCommentsApi().then((data) => {
      setBackendComments(data);
    });
    fetch("https://publish-content-serverart.herokuapp.com/content/history", {
            headers: {
                authorization: authToken
            }
        }).then((res)=>res.json()).then((data)=> {
            setData(data)
            //console.log(data)
        })
  }, []);

  return (
    <>
    <div className="comments-page">
    
        
         <div>
         <div className="comments">
          <h3 className="comments-title">Comments</h3>
          <div className="comment-form-title">Write comment</div>
          <CommentForm submitLabel="Write" handleSubmit={addComment} />
          <div className="comments-container">
            {rootComments.map((rootComment) => (
              <Comment
                key={rootComment.id}
                comment={rootComment}
                replies={getReplies(rootComment.id)}
                activeComment={activeComment}
                setActiveComment={setActiveComment}
                addComment={addComment}
                currentUserId={currentUserId}
              />
            ))}
          </div>
        </div>
                    
        </div>
        
    
    
    </div>
    </>
  );
};

export default Comments;