import { useState } from "react";
import Logout from "../logout/logout";
import "./post.css";
import Comment from "../comment";
import Comments from "../comments";

const Posts = () => {

    const [activeTab, setActiveTab] = useState("PUBLISH");

    return (
        <div style={{ color: "black" }}>
            {/* Header */}
            <div className="header__title">
                <h4>10X Academy</h4>
            </div>
            {/* Sidebar */}
            <div className="main__content">
                <div className="sidebar__wrapper">
                    <ul>
                        <li onClick={() => setActiveTab("PUBLISH")}>
                            Publish Content
                        </li>
                        <li onClick={() => setActiveTab("COMMENTS")}>
                            Comment
                        </li>
                        <li onClick={() => setActiveTab("HISTORY")}>
                            History
                        </li>
                        <li>
                            <Logout />
                        </li>
                    </ul>
                </div>
                <div className="sidebar__content">
                    {activeTab == "PUBLISH" &&
                        <div>
                            <textarea rows={10} cols={100} value={"What is Loreum Ipsum ?In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available."} />
                            <div className="footer__buttons">
                                <button type="submit" className="btn btn-primary"  >
                                    Edit
                                </button>
                                <button type="submit" className="btn btn-primary"  >
                                    Save
                                </button>
                                <button type="submit" className="btn btn-primary"  >
                                    Publish
                                </button>
                            </div>
                        </div>}
                    {activeTab == "COMMENTS" && <div><Comments/></div>}
                    {activeTab == "HISTORY" && <div>History of Posts</div>}
                </div>
            </div>
            {/* Content */}


        </div>
    )
}
export default Posts;