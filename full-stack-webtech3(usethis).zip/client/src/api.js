export const getComments = async () => {
    return [
      {
        id: "1",
        body: "Nice",
        username: "ashish",
        userId: "1",
        parentId: null,
        createdAt: "2021-08-09T15:41:20.092+03:00",
      },
      {
        id: "2",
        body: "????",
        username: "kevin",
        userId: "2",
        parentId: null,
        createdAt: "2021-08-09T15:41:20.092+03:00",
      },
      {
        id: "3",
        body: "not good",
        username: "yogesh",
        userId: "2",
        parentId: "1",
        createdAt: "2019-04-16T23:12:37+03:00",
      },
      {
        id: "4",
        body: "impressed",
        username: "vivek",
        userId: "2",
        parentId: "2",
        createdAt: "2019-04-16T23:12:37+03:00",
      },
    ];
  };
  
  export const createComment = async (text, parentId = null) => {
    return {
      id: Math.random().toString(36).substr(2, 9),
      body: text,
      parentId,
      userId: "1",
      username: "John",
      createdAt: new Date().toISOString(),
    };
  };
  